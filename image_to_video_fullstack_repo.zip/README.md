
# Image → Video AI Full Stack

Includes:
- Stable Video Diffusion
- AnimateDiff
- ControlNet Motion
- YouTube Shorts Presets
- LLM Auto-Prompt
- Dockerized Stack

Fully local, open-source, GPU-ready.
