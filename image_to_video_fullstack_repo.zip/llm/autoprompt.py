
# Local LLM auto-prompt stub
def generate_prompt(image_meta):
    return "cinematic slow motion, dramatic lighting"
