
# Image to Video AI Pipelines (Open Source)

Includes:
- Stable Video Diffusion
- AnimateDiff
- ModelScope Text-to-Video
- Pika-style (Deforum-like) workflow

All workflows are local and open-source.
