
import os, time
from PIL import Image

INPUT_DIR = "images"
OUTPUT_DIR = "output"

os.makedirs(OUTPUT_DIR, exist_ok=True)

for file in os.listdir(INPUT_DIR):
    if file.lower().endswith((".png", ".jpg", ".jpeg")):
        out = os.path.join(OUTPUT_DIR, file + ".mp4")
        if os.path.exists(out):
            continue
        print("Processing", file)
        time.sleep(5)
        open(out, "wb").close()  # placeholder for video output
