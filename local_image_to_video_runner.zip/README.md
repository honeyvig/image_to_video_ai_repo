
Local Image to Video Runner

1. Put images into /images
2. Double-click run_local_image_to_video.bat
3. Videos will be generated in /output

GPU recommended.
